
<?php


// Use Unifont to render text
  $content = stripslashes($argv[1]);
  $content = wordwrap($content, 32, "\n");
  $content = 
  $content = $content."\n";
require __DIR__ . '/vendor/autoload.php';
use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;
use Mike42\Escpos\Printer;
use Mike42\Escpos\Experimental\Unifont\UnifontPrintBuffer;
$connector = new NetworkPrintConnector("192.168.1.87", 9100);
$printer = new Printer($connector);
$printer -> initialize();
$unifontBuffer1 = new UnifontPrintBuffer(__DIR__ ."/unifont-14.0.01.hex");
$unifontBuffer2 = new UnifontPrintBuffer(__DIR__ ."/unifont-12.1.03.hex");
try {$lines = explode("\n",$content);
  $path="";
  for ($i = 0; $i < count($lines); $i++){
	$path = $path .$lines[$i] . "\n";
	$dong = $lines[$i];
	if($dong[0]=="#"){$printer -> setTextSize(2,3);$printer -> text($path);$path="";continue;};//chu nho
	//moi hai dong thi in mot lan voi unifonbuffer khac nhau
	if(is_int($i/2)){
		$printer = new Printer($connector);
		$printer -> initialize();
		$printer -> setPrintBuffer($unifontBuffer2);
		$printer -> setTextSize(3,3);
		$printer -> text($path);
		$path="";
		continue;
	}
	if(is_int($i/1)){
		$printer = new Printer($connector);
		$printer -> initialize();
		$printer -> setPrintBuffer($unifontBuffer1);
		$printer -> setTextSize(3,3);
		$printer -> text($path);
		$path="";
	}  
  }
	$printer -> cut();
} finally {
    $printer -> close();
}

//~ // Use render text to image
  //~ $content = stripslashes($argv[1]);
  //~ $content = wordwrap($content, 32, "\n");
  //~ $content = $content."\n";
//~ require __DIR__ . '/vendor/autoload.php';
//~ use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;
//~ use Mike42\Escpos\Printer;
//~ use Mike42\Escpos\EscposImage;
//~ use Mike42\Escpos\CapabilityProfile;
//~ use Mike42\Escpos\PrintBuffers\EscposPrintBuffer;
//~ use Mike42\Escpos\PrintBuffers\ImagePrintBuffer;
//~ $profile = CapabilityProfile::load("RP326");
//~ $connector = new NetworkPrintConnector("192.168.1.87", 9100);
//~ $imageBuffer = new ImagePrintBuffer();
//~ $imageBuffer -> setFont(__DIR__."/NotoSansMono-Regular.ttf");
//~ $imageBuffer -> setFontSize(44);
//~ $textBuffer = new EscposPrintBuffer();
//~ $printer = new Printer($connector,$profile);
//~ $printer -> initialize();
//~ try {
	//~ $printer -> setPrintBuffer($imageBuffer);
    //~ $printer -> text($content);
	//~ $printer -> cut();
//~ } finally {
    //~ $printer -> close();
//~ }

?>





