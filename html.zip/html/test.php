
<?php

$content = 'Thẻ số: 1
04:52:52, 15/2/2022 *
Tổng tiền: 212000
------------
1: phở thậpcẩm
35000 = 35000
------------
2: bún thậpcẩm
35000 = 35000
------------
3: mìtôm nạm gầu
35000 = 35000
------------
4: nhúngbát80 giá 1trứng 1giá 20kmuôitái
80000 + 7000 + 20000 = 107000
------------';
$dong = explode("\n", $content);
	for ($i = 0; $i < count($dong); $i++) {
	  echo $dong[$i];
	  echo $i;
    usleep(100000);

	}
	
?>
