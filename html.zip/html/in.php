<?php
//shell_exec('php ./in2.php');
$content = $_POST['inbep']."\n";
$content = str_replace("\n\n","\n",$content);
// Change the line below to your timezone!
date_default_timezone_set('Asia/Ho_Chi_Minh');
$date = "#".date('d/m/Y H:i:s', time())."\n";

//function write(stt,str){

//}
//function read(stt){

//return $content
//}
$fileLocation = getenv("DOCUMENT_ROOT") . "/nhatky/".$_POST['stt'];

if($_POST['trangthai']=="datmon"){
  file_put_contents($fileLocation, $date);
  file_put_contents($fileLocation, $content, FILE_APPEND);
}
if($_POST['trangthai']=="goithem"){
file_put_contents($fileLocation, $date, FILE_APPEND);
file_put_contents($fileLocation, $content, FILE_APPEND);
}
if($_POST['trangthai']=="nhatky"){
$fileLocation = getenv("DOCUMENT_ROOT") . "/nhatky/".$_POST['stt'];
$myfile = fopen($fileLocation, "r") or die("Unable to open file!");
$content = fread($myfile,filesize($fileLocation));
fclose($myfile);
}
exec('php ./in2.php "' . addslashes($content) . '"');
?>
