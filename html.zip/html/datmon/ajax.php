<?PHP
//phai thiet lap de apache co quyen tao file sudo chown www-data /var/www/html/datmon/don
$fileLocation = getenv("DOCUMENT_ROOT") . "/datmon/don/".$_POST['stt'];
  $content = $_POST['donhang'];
file_put_contents($fileLocation, $content);
?>


