<?php
//phai thiet lap de apache co quyen tao file sudo chown www-data /var/www/html/thanhtoan/
$fileLocation = getenv("DOCUMENT_ROOT") . "/thanhtoan/tinhtien.csv";
$myfile = fopen($fileLocation, "r") or die("Unable to open file!");
echo fread($myfile,filesize($fileLocation));
fclose($myfile);
?>
