


<?php
//phai thiet lap de apache co quyen tao file sudo chown www-data /var/www/html/datmon/don
$fileLocation = getenv("DOCUMENT_ROOT") . "/datmon/don/".$_POST['stt'];
$myfile = fopen($fileLocation, "r") or die("Unable to open file!");
echo fread($myfile,filesize($fileLocation));
fclose($myfile);
?>

