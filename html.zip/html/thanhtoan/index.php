<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0017)http://localhost/ -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title></title>
    <meta meta name="viewport" content="user-scalable=no" />
    <style>
		body  {
    padding-bottom: 500px;
}
	#tracuu {
		margin: 5%;
	}
	#tracuu h1 {
		
    text-align: center;
    font-size: 5em;
}
	
    #tracuu input[type='number']{
    width: 100%;
    font-size: 15em;
    text-align: center;
    margin: 0%;
}
#tracuu input[type='button']{
    width: 100%;
    font-size: 5em;
    margin-top: 1em;
     margin-bottom: 1em;
}
#ketqua input[type='button']{
	display: none;
    width: 100%;
    font-size: 1em;
    margin-bottom: 1em;
}
#ketqua {
    font-size: 5em;
    display: none;
}
#ketqua pre{
    overflow: hidden;
    width: 100%;
    font-size: 1.5em;
    white-space: -moz-pre-wrap !important;  /* Mozilla, since 1999 */
    white-space: -pre-wrap;      /* Opera 4-6 */
    white-space: -o-pre-wrap;    /* Opera 7 */
    white-space: pre-wrap;       /* css-3 */
    word-wrap: break-word;       /* Internet Explorer 5.5+ */
    white-space: -webkit-pre-wrap; /* Newer versions of Chrome/Safari*/
    
}
#back input[type='button'] {
    font-size: 5em;
    width: 100%;
    margin-top: 10%;
}
input[type='number']{
	    background-color: ghostwhite;
}
#ketqua .back{
    display: block;
    position: fixed;
    top: 0px;
    background-color: chartreuse;
}
#tracuu .submit{
	background-color: chartreuse;
}
    </style>
    <script src="./index_files/jquery.min.js"></script>
    <script src="/tiengviet.js"></script>
    <script>
		$(document).ready(function(){
    $('#tracuu input[type="button"].submit').click(function(event){
		
		 $('#tracuu').toggle();
		 $('#back').toggle();
		 $('#ketqua').toggle();
		$('#ketqua input[type="button"]').css("display", "block");
		 
var banggia = function () {
    var tmp = null;
    $.ajax({
        'async': false,
        'type': "POST",
        'global': false,
        'dataType': 'html',
        'url': "./tinhtien.php?first",
        'data': { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
        'success': function (data) {
            tmp = data;
        }
    });
    return tmp;
}();

$.ajax({
              method: "POST",
              url:    "./ajax.php",
              data: { stt: $($('#tracuu input[type="number"]')[0]).val()},
             }).done(function( data ) {
			//console.log(data);
			//console.log(banggia);
            var r=$.trim(data)
            if(r!="Unable to open file!"){
				var napkhachgoi="";
				var result="";
				r=r.slice(r.lastIndexOf('*') + 1);
				napkhachgoi = r.split("\n");
				total=0;
				for (let i = 0; i < napkhachgoi.length; i++) {
					if(typeof napkhachgoi[i] == 'undefined' || napkhachgoi[i]=="" || napkhachgoi[i]==" ")continue;
					console.log(napkhachgoi[i]);
					result+=tinhtien(napkhachgoi[i],banggia)+"\n"+"------------"+"\n";
					
					//console.log(napkhachgoi[i]);
				}
				
				
			}else{r="Không có thông tin hoặc điền sai số thẻ"}
            
  result="Tổng tiền: "+total+"\n"+"------------"+"\n"+result;   
  
  //console.log(banggia);
  result=tiengviet(result,"themdau");  
  result=result.replace(/NaN/g,"?");    
  $('#ketqua pre').html(result);
  inbep=result
  });
  
	   });
    
    
		$('#ketqua input[type="button"].back').click(function(event){
		$('#tracuu').css("display", "block");
		 $('#back').css("display", "block");
		 $('#ketqua').toggle();
	})
function soitien (str, strArray) {
	
	if(str.indexOf('bat')!=-1){
		
		var r=str.substring(str.indexOf('bat')+3);
		if(str.indexOf('batbe')!=-1){
		
			r=20000;
			return r;
		}
		r=parseInt(r)*1000;
		return r;
	}
	
	
	if(str.indexOf('k')!=-1){
		var e=str.split('k');
		for (var j=0; j<e.length; j++) {
			var t=reverse(e[j]);
			if(!isNaN(parseInt(t))){
				t=t.substring(0,2);
				t=reverse(t);
				r=t.match(/\d+/)[0];
				r=parseInt(r)*1000;
				return r;
			}
		}
	}
	if(typeof strArray == 'undefined')return str;
	var d=strArray.split("\n");
	
    for (var j=0; j<d.length; j++) {
		var m=d[j].substring(0,d[j].indexOf(','));
		
        if (m==str){
			var r=d[j];
			r=r.substring(r.indexOf(',')+1);
			console.log(r);
			return r;
			
		}
    }
    return str;
}
function thoigian(){
	var d = new Date();
    var utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    var nd = new Date(utc + (3600000*7));
return nd.toLocaleString("vi-VN")
}
var total=0;
function sortFunction(a, b) {
    if (a[0] === b[0]) {
        return 0;
    }
    else {
        return (a[0] < b[0]) ? -1 : 1;
    }
}
function sapxep(str){
	var thutu="thapcam tai nam gau cuongtim timcat bap sotvang moc gan";
	str=str.split(" ");
	var sothutu=[];
	for (var j=0; j<str.length; j++) {
		sothutu[j]=[thutu.indexOf(str[j]),j];
		
	}
	sothutu.sort(sortFunction);
	var r="";
	for (var j=0; j<str.length; j++) {
		r+=str[sothutu[j][1]];
		
	}
	//console.log(r);
	r=r.replace(/ /g, '');
	return r;
}
var sobat=0;
function tinhtien(str,banggia){
	
	var strold=str;
	str=str.replace("namchin","nam");
	var monchinh="";
	var monphu="";
	//console.log(str);
	//var d=str.substring(str.indexOf(':')+1);
	//console.log(str);
	//~ var d;
	//~ d=str.split(' ');
	var m;
	var n;
	//~ console.log(d);
	//~ for (let i = 0; i < d.length; i++) {
		//~ console.log(d[i]);
		//~ if(!isNaN(parseInt(d[i]))){m=d[i];n=i;break;};
		//~ if(isNaN(parseInt(d[i]))){
			//~ monchinh+=d[i];
			//~ 
		//~ }
	//~ }
	//~ console.log(monchinh);
	//console.log(d[n]);
	//monchinh="1 "+monchinh+" ";
	//n=n+2;
	//str=monchinh+str.substring(str.indexOf(m));
	var sl=parseInt(str);
	if(str.indexOf("pho")!=-1 || str.indexOf("bun")!=-1 || str.indexOf("mitom")!=-1){
		if(!isNaN(sl)){sobat+=sl;}
	}

	//console.log(banggia);
	str=str.replace(/pho/g,"");
	str=str.replace(/bun/g,"");
	str=str.replace(/mitom/g,"");
	str=str.replace(/nhung/g,"");
	str=str.replace(/beo/g,"");
	str=str.replace(/gia/g,"");
	str=str.replace(/itbanh/g,"");
	str=str.replace(/nhieubanh/g,"");
	str=str.replace(/ithanh/g,"");
	str=str.replace(/nhieuhanh/g,"");
	str=str.replace(/khonghanh/g,"");
	str=str.replace(/khongmichinh/g,"");
	

	var r;
	//console.log(sl.toString().length);
	
	monchinh=str.substring(sl.toString().length);
	monchinh=sapxep(monchinh);
	if(str.substring(0,6)=="moibat"){
		monchinh=str.substring(6);
		var x=parseInt(monchinh);
		sl=sobat*x;
		monchinh=monchinh.substring(monchinh.indexOf(" "));
		console.log(sl);
		};
	monchinh=$.trim(monchinh);
	console.log(monchinh);
	var tien=soitien(monchinh,banggia);
	var rthehien="";
	if(!isNaN(tien)){rthehien=sl+"x"+tien;}
	r=sl*tien+"+";
	
	console.log(r);
	
	//console.log(monchinh+" "+soitien(monchinh,banggia));
	//~ for (let i = n; i < d.length; i++) {
		//~ //console.log(d[i]);
		//~ d[i]=$.trim(d[i]);
		//~ if(d[i]=="1gia" || d[i]=="1nuocbeo" || d[i]=="1beo")continue;
		//~ if(!isNaN(parseInt(d[i]))){
			//~ var s=parseInt(d[i]);
			//~ if(d[i].indexOf('k')!=-1){
				//~ 
				//~ r+=s*1000+"+";
				//~ //console.log(r);
				//~ //i++;
				//~ continue;
			//~ }else{
				//~ 
				//~ var m=d[i].replace(/[0-9]/g, '');
				//~ g=soitien(m,banggia);
				//~ r+=s+"*"+g+"+";;
			//~ }
			//~ 
			//~ //console.log(r);
		//~ };
		//~ //console.log(d[i]);
		//~ //var g=soitien(d[i],banggia);
		//~ //r+=g+" + ";
		//~ //
	//~ }
	
	var s=r.split('+');
		r="";
	for (let v = 0; v < s.length; v++) {
		if(s[v].indexOf('*')!=-1){
			s[v]=eval(s[v]);
		}
		if(v<s.length-1){r+=s[v]+'+';}
		if(v==s.length-1){r+=s[v];}
	}
	
	r=$.trim(reverse(r));
	if(r.substring(0,1)=="+")r=r.substring(1);
	r=reverse(r);
	//console.log(r);
	r=r.replace(/ /g,'');
	//console.log(r);
	r=r.replace(/\+/g,' + ');
	
	
	var t=eval(r);
	
	total+=t;
	if(rthehien!=""){r=strold+"\n"+rthehien+" = "+t;}
	if(rthehien==""){r=strold;}
	sl=0;
	return r;
	
}
function reverse(str){
    return [...str].reverse().join("");
}

var inbep="";
$('#ketqua input[type="button"].in.thanhtoan').click(function(event){
	var temp=inbep;
	inbep="Thẻ số: "+$($('#tracuu input[type="number"]')[0]).val()+"\n#"+thoigian()+" *\n"+inbep;
	//console.log(inbep);
$.ajax({
  method: "POST",
  url: "/in.php",
  data: { inbep: inbep }

}) 
inbep=temp;
}) 
$('#ketqua input[type="button"].in.nhatky').click(function(event){
$.ajax({
  method: "POST",
  url: "/in.php",
  data: { stt: $($('#tracuu input[type="number"]')[0]).val(), trangthai: "nhatky" }

}) 
}) 
});

    </script>
    
  </head>
  <body>
<span id='tracuu'>
	<h1>Thẻ số:</h1>
	<input type='number' name='stt' value='' class='stt' />
    <input type='button' value='OK' class='submit stt'/>
    
</span>
<span id='ketqua'>
	<input type='button' value='Quay lại' class='back'/>
<pre></pre>
	<input type='button' value='In' class='in thanhtoan'/>
	<input type='button' value='In nhật ký khách gọi' class='in nhatky'/>
</span>
<span id='back'>
<a href='../' target='_self'><input type='button' value='Quay lại' class='back'/></a>
<a href="/datmon/index.php" target="_self"><input type='button' value='Đặt món' class='datmonmoi'</button></a>
<a href="/suamon/index.php" target="_self"><input type='button' value='Sửa/thêm món' class='suathemmon'</button></a>
</span>
</body></html>
