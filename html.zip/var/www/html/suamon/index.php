<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0024)http://localhost/datmon/ -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title></title>
    <meta meta name="viewport" content="user-scalable=no" />
    <link rel="stylesheet" href="/datmon/datmon.css" type="text/css">
    <style>
		body  {
    padding-bottom: 500px;
}
	#chotdon {
       text-align: center;
    width: 100%;
    background-color: white;
    height: 9em;
    position: fixed;
    top: 0px;
}
	#chotdon input {
    font-size: 5em;
    width: 100%;
        background-color: chartreuse;
            margin-bottom: 0.5em;
}
#back input[type='button'] {
    font-size: 5em;
    width: 100%;
    margin-top: 10%;
}
#dienstt {
    width: 100%;
    display: none;
    position: relative;
    margin: 0;
    padding: 10%;
}
#dienstt input[type='number']{
    font-size: 10em;
    line-height: 1em;
    width: 48%;
    display: inline-block;
    position: relative;
    text-align: center;
}
#dienstt input[type='button']{
    width: 100%;
    font-size: 10em;
    margin-top: 10%;
}
#dienstt h1{
    text-align: center;
    font-size: 4em;
    display: inline-block;
    width: 40%;
}
#don{
    font-size: 5em;
    margin: 10px;
    padding: 0px;
    overflow: hidden;
    width: 100%;
    white-space: -moz-pre-wrap !important;  /* Mozilla, since 1999 */
    white-space: -pre-wrap;      /* Opera 4-6 */
    white-space: -o-pre-wrap;    /* Opera 7 */
    white-space: pre-wrap;       /* css-3 */
    word-wrap: break-word;       /* Internet Explorer 5.5+ */
    white-space: -webkit-pre-wrap; /* Newer versions of Chrome/Safari*/
    border-bottom: black;
    border-style: solid;
}

#suamon{
	display: none;
}
#tracuu {
		margin: 5%;
	}
	#tracuu h1 {
	    text-align: center;
    font-size: 4em;
    display: inline-block;
    width: 40%;
}
	
    #tracuu input[type='number']{
   font-size: 10em;
    line-height: 1em;
    width: 50%;
    display: inline-block;
    position: relative;
    text-align: center;
}
#tracuu input[type='button']{
    width: 100%;
    font-size: 5em;
    margin-top: 1em;
     margin-bottom: 1em;
}

#ketqua input[type='button'].back{
	display: none;
    width: 100%;
    font-size: 1em;
    margin-bottom: 1em;
}
#ketqua {
    font-size: 5em;
    display: none;
}
#ketqua pre{
    overflow: hidden;
    width: 100%;
    font-size: 1.5em;
    white-space: -moz-pre-wrap !important;  /* Mozilla, since 1999 */
    white-space: -pre-wrap;      /* Opera 4-6 */
    white-space: -o-pre-wrap;    /* Opera 7 */
    white-space: pre-wrap;       /* css-3 */
    word-wrap: break-word;       /* Internet Explorer 5.5+ */
    white-space: -webkit-pre-wrap; /* Newer versions of Chrome/Safari*/
    
}
input[type='number']{
	    background-color: ghostwhite;
}
#back {
    padding: 1%;
}
#tracuu .submit{
	background-color: chartreuse;
}
    </style>
    <script src="./index_files/jquery.min.js"></script>
    <script src="./index_files/htmldiff.js"></script>
    <script src="/tiengviet.js"></script>
    <script>
		//var mon;
		//var mon1;
		//var mon2;
		//var them;
		var napkhachgoi=[];
		var banso;
		//var khachgoicu=[];
		var stt;
		var yeucau=[];
		var themsua="";
	function xulyyeucau(str){
		
		var r=[];
		if(str.length > 0)yeucau[0]="";
		var k=0;
		var w=str.split(" ");
		for (let i = 0; i < w.length; i++) {
			
			if(typeof w[i] == 'undefined'){continue};
			if(!isNaN(parseInt(w[i])) || w[i].substring(0,6)=="moibat"){
				k++;
				r[k]="";
			}
			r[k]+=w[i]+" ";
			if(w[i].substring(0,6)=="moibat"){
				r[k]+=w[i+1]+" "+w[i+2]+" ";
				i+=2;
			}
		}
		console.log(r);
		return r;
	}
	var sobat=0;
	function lenyeucau(str){
		
		var noidung="";
		str=str.join("\n");
		
		str=str.split("\n");
		for (let i = 0; i < str.length; i++) {
			str[i]=$.trim(str[i]) ;
			
			if(typeof str[i] == 'undefined' || str[i]=="" || str[i]=="undefined"){continue};
			
			var sl=parseInt(str[i]);
			var m=str[i].replace(sl.toString(),"");
			if(str[i].substring(0,6)=="moibat"){
				
				sl=str[i].replace("moibat","");
				sl=$.trim(sl) ;
				var x=parseInt(sl);
				
				m=sl.substring(sl.indexOf(" "));
				console.log(m)
				sl="moibat"+x;
				
			}
			
			m=tiengviet(m,"themdau");
			if(sl.toString().substring(0,6)=="moibat"){
				noidung+='<div class="checklist"><label name="yeucau'+i+'">'+tiengviet(sl,"themdau")+' '+m+'</label><div class="options position" ><button class="doimon" name="doimon" type="button" onclick="suayeucau(this)">Đổi</button><button class="xoabo" name="xoabo" type="button" onclick="boyeucau(this)">Bỏ</button></div></div>';
			}else{
			noidung+='<div class="checklist"><div class="themsoluong"><input type="button" value="-" class="qtyminus minus" field="quantity" /><input type="text" name="quantity" value="'+sl+'" class="qty" readonly/><input type="button" value="+" class="qtyplus plus" field="quantity" /></div><label name="yeucau'+i+'">'+m+'</label><div class="options position" ><button class="doimon" name="doimon" type="button" onclick="suayeucau(this)">Đổi</button><button class="xoabo" name="xoabo" type="button" onclick="boyeucau(this)">Bỏ</button></div></div>';
			}
			
			
			
		}
		
		return noidung
	}
	
	var yeucaumoi="";
	var themyeucaubool=false;
	var suayeucaubool=false;
	function themyeucau(el){
			   $slot=$(el);
			    $("#datmon").show();
			   $("#duyetdonhang").hide();
			   $(".suadonhang").show();
			   $("#menu").removeClass('taodon');
			   yeucaumoi="";
			   themyeucaubool=true;
			   suayeucaubool=false;
			   //$("#menu").addClass('taodon');
			   $(".soluongshow").hide();
				//$(".startuphidden").hide();
				$("#duyetdonhang").hide();
	}
	function suayeucau(el){
			   $yeucaucansua=$(el).parent().parent();
			    $("#datmon").show();
			   $("#duyetdonhang").hide();
			   $(".suadonhang").show();
			   $("#menu").removeClass('taodon');
			   yeucaumoi="";
			   suayeucaubool=true;
			   themyeucaubool=false;
			   $("#menu").addClass('taodon');
				$(".soluongshow").hide();
				//$(".startuphidden").hide();
				$("#duyetdonhang").hide();
	}
	function boyeucau(el){
		var r=el;
		themsua=themsua+"BỎ: "+$(r).parent().parent().find(".qty").val()+" "+$(r).parent().parent().find("label").html()+"\n";
		console.log(themsua);
		$(r).parent().parent().remove();
		$("#suadonhangnay").hide();
		
	}
	
	function reverse(str){
    return [...str].reverse().join("");
}	
	function plus(el){
	 let $input = $(el).prev('input.qty');
	let val = parseInt($input.val());
	$input.val( val+1 ).change();
   };
   function minus(el){
	 let $input = $(el).next('input.qty');
	var val = parseInt($input.val());
	var x=0;
	if (val > x) {
		$input.val( val-1 ).change();
		if($input.parent().parent().attr('id')=="donhang"){$input.val( "moibat" ).change();};
	} 
   };
	var yeucaucansua;
	var slot;
	var donhang;
	$(document).ready(function(){
		$("#duyetdon").click(function(event){
			$("#duyetdonhang").hide();
			$("#dienstt").show();
			window.scrollTo(0, 0);
			donhang="";
			donhang+=$('#donhang .checklist').map(function() {
				var sl=$(this).find("input.qty").val();
				var m=$(this).find("label").html();
				if(sl=="" || m=="")return;
				console.log(m.substring(0,6));
				if(typeof sl == 'undefined' && m.substring(0,6)=='mỗibát'){return m;};
				return sl+m;
			}).get().join('\n')+" ";
			donhang=$.trim(donhang) ;
		})
		
		$(".taodon button").click(function(event){
			var e=$(this).attr('name');
			var s=reverse(e);
			if(s[0]=="k"){don=don+e;}
			else{don=don+" "+e;}
			
			
			
	   })
	   $(".suadonhang button").click(function(event){
					var e=$(this).attr('name');
					var s=reverse(e);
					if(s[0]=="k"){yeucaumoi=yeucaumoi+e;}
					else{yeucaumoi=yeucaumoi+" "+e;}
			   })
	
	
	   $("#chotdon .submit").click(function(event){
			$("#datmon").hide();
			$("#menu .mon2").hide();
			$("#menu .size1").hide();
			$("#menu .tuychon").hide();
		   if(!themyeucaubool && !suayeucaubool){
			   
			   //$("#chotdon .submit").hide();
			   $("#back").hide();
			   
					   $("#suadonhangnay").hide();
			   $("#duyetdonhang").show();
			   var p=lenyeucau(xulyyeucau(don));
			   
			   $("#donhang").html(p);
			   }
		  if(themyeucaubool || suayeucaubool){
		   $(".suadonhang").hide();
				   $("#duyetdonhang").show();
				   var p=lenyeucau(xulyyeucau(yeucaumoi));
				   
				   if(p!=""){
					   
					   if(themyeucaubool){
						   $(p).insertBefore( $slot );
						   themyeucaubool=false;
						   themsua=themsua+"THÊM: "+yeucaumoi+"\n";
						   console.log(themsua);
					   }
					   if(suayeucaubool){
						   $(p).insertAfter( $yeucaucansua );
						   $yeucaucansua.remove();
						   suayeucaubool=false;
						   themsua=themsua+"ĐỔI: "+$yeucaucansua.find(".qty").val()+" "+$yeucaucansua.find("label").html()+" THÀNH: "+yeucaumoi+"\n";
						   console.log(themsua);
					   }
				   }
			}
		    $(".themsoluong .qtyplus.plus").click(function(event){plus(this);});
				$(".themsoluong .qtyminus.minus").click(function(event){minus(this);});
		   
	   })
	   $("#menu .mon1").click(function(event){
			$("#menu .mon2").show();
			$("#menu .size1").show();
			$("#menu .tuychon").show();
		   })
		$("#menu .soluong button").click(function(event){
			$("#menu .startuphidden").hide();
			$(".soluongshow").show();
			window.scrollTo(0, 0);
		});
		//$('.checklist input[type="checkbox"]').prop('checked', false);
		
	    $('#tracuu input[type="button"].submit').click(function(event){
		stt=$('#tracuu input[type="number"]').val();
		$('#dienstt input[type="number"].dienstt').val(stt);
		console.log(stt);
		 $('#tracuu').toggle();
		

$.ajax({
              method: "POST",
              url:    "./ajax.php",
              data: { stt: $($('#tracuu input[type="number"]')[0]).val()},
             }).done(function( data ) {
			
            var r=$.trim(data) 
            if(r=="Unable to open file!" || r==""){
				r="Không có thông tin hoặc điền sai số thẻ";
				
				$('#ketqua').css("display", "block");
				$('#ketqua pre').html(r);
				$('#ketqua input[type="button"].back').css("display", "block");
				$('#back').toggle();
				}else {

banso=reverse(r).slice(r.lastIndexOf('*') + 1);
banso=banso.substring(0,banso.indexOf(':'));
banso=$.trim(reverse(banso));
banso=parseInt(banso);
console.log(banso);
$("#dienstt input.banso").val(banso).change();

r=r.slice(r.lastIndexOf('*') + 1);
console.log(r);
//napkhachgoi = r.split("\n");
//console.log(napkhachgoi);
//khachgoicu = r.split("\n");
//khachgoi=napkhachgoi;
//loadkhach(1);
//chotkhach(1);
var p=lenyeucau(xulyyeucau(r));
console.log(p);
$("#donhang").html(p);
 $(".themsoluong .qtyplus.plus").click(function(event){plus(this);});
				$(".themsoluong .qtyminus.minus").click(function(event){minus(this);});
				$( "#donhang" ).append("<input id='themdonhang' type='button' value='Thêm món' class='submit themdonhang' onclick='themyeucau(this)'/><a href='/index.php' target='_self'><input type='button' value='Thoát' class='back themdonhang'/></a>");
		   $("#back").hide();
		  $("#datmon").hide();
					$('#suamon').toggle();
					}
  
  });
  
	   });
    $('#dienstt input[type="button"].back').click(function(event){
	$('#duyetdonhang').show();
		$('#dienstt').hide();
});

    $('#ketqua input[type="button"].back').click(function(event){
		$('#tracuu').css("display", "block");
		 $('#back').css("display", "block");
		 $('#ketqua').toggle();
	})
		
	   
	   
	  //~ $("#menu .mon1 .checklist").click(function(event){
		   //~ 
		   //~ $("#menu .mon1 .checklist").removeClass("active");
		   //~ $("#menu .mon1 .checklist").addClass("noactive");
		   //~ $(this).removeClass("noactive");
		   //~ $(this).addClass("active");
		   //~ $("#menu .mon1 .checklist.noactive input[type='checkbox']").prop('checked', false);
		   //~ 
		   //~ });
		//~ $("#menu .mon1 .checklist.loai1").click(function(event){
			//~ $("#menu .size1 .checklist.loai2 input[type='checkbox']").prop('checked', false);
		//~ })
	   //~ $("#menu .size1 .checklist").click(function(event){
		   //~ 
		   //~ $("#menu .size1 .checklist").removeClass("active");
		   //~ $("#menu .size1 .checklist").addClass("noactive");
		   //~ $(this).removeClass("noactive");
		   //~ $(this).addClass("active");
		   //~ $("#menu .size1 .checklist.noactive input[type='checkbox']").prop('checked', false);
		   //~ });
		 //~ $("#itbanh").click(function(event){
			    //~ $("#nhieubanh").prop('checked', false);
		 //~ });
		 //~ $("#nhieubanh").click(function(event){
			    //~ $("#itbanh").prop('checked', false);
		 //~ });
		 //~ $("#nhieuhanh").click(function(event){
			    //~ $("#ithanh").prop('checked', false);
			    //~ $("#khonghanh").prop('checked', false);
		 //~ });
		 //~ $("#ithanh").click(function(event){
			    //~ $("#nhieuhanh").prop('checked', false);
			    //~ $("#khonghanh").prop('checked', false);
		 //~ });
		 //~ $("#khonghanh").click(function(event){
				//~ $("#ithanh").prop('checked', false);
			    //~ $("#nhieuhanh").prop('checked', false);
		 //~ });
	   //$("#menu .mon1 .checklist #pho").click(function(event){
		 //document.getElementById("bun").checked = false;
		 //mon1="pho";
	   
	   //$("#menu .mon1 .checklist #bun").click(function(event){
		 //document.getElementById("pho").checked = false;
		 //mon1="bun"
	   //});
	   //~ $("#thapcam").click(function(event){
		 //~ if ($("#thapcam").prop('checked')===true) {
			//~ $("#menu .mon2 .checklist .notmain").prop('checked', false);
			//~ mon2="thapcam ";
		//~ } 
	   //~ });
	   //~ $("#menu .mon2 .checklist .notmain").click(function(event){
		 //~ if ($("#thapcam").prop('checked')===true) {
			//~ $("#thapcam").prop('checked', false);
			//~ mon2="";
		//~ } 
	   //~ });
	   //~ $("#nhung").click(function(event){
		   //~ $("#menu .size1 .checklist input[type='checkbox']").prop('checked', false);
		   //~ $("#bat80").prop('checked', true);
	   //~ })
	   //~ $("#menu .size1 .checklist.loai1 input[type='checkbox']").click(function(event){
		   //~ if ($("#nhung").prop('checked')===true){
				//~ $(this).prop('checked', false);
		   //~ }
	   //~ })
	   //~ 
	   //~ 
	   //~ $(".themsoluong.loai1 .qtyplus.plus").click(function(event){
		 //~ let $input = $(this).prev('input.qty');
		//~ let val = parseInt($input.val());
		//~ $input.val( val+1 ).change();
	   //~ });
	   //~ $(".themsoluong.loai1 .qtyminus.minus").click(function(event){
		 //~ let $input = $(this).next('input.qty');
		//~ var val = parseInt($input.val());
		//~ var x=0;
		//~ if($input.parent().parent().attr('id')=="khach"){x=1;};
		//~ if (val > x) {
			//~ $input.val( val-1 ).change();
		//~ } 
	   //~ });
	   //~ 
	   //~ $(".themsoluong.loai2 .qtyplus.plus").click(function(event){
		 //~ let $input = $(this).prev('input.qty');
		//~ let val = parseInt($input.val());
		//~ var id = $(this).parent().parent().attr('id');
		//~ if(id!="themquay" && val<10){$input.val( val+5+"k" ).change();}
		//~ if(id=="themquay" && val<20){$input.val( val+5+"k" ).change();}
	   //~ });
	   //~ $(".themsoluong.loai2 .qtyminus.minus").click(function(event){
		 //~ let $input = $(this).next('input.qty');
		//~ let val = parseInt($input.val());
		//~ var x=0;
		//~ if (val > x) {
			//~ if(val>5)$input.val( val-5+"k" ).change();
			//~ if(val==5)$input.val("0").change();
		//~ } 
	   //~ });
	   //~ $(".themsoluong.loai3 .qtyplus.plus").click(function(event){
		 //~ let $input = $(this).prev('input.qty');
		//~ let val = parseInt($input.val());
		//~ if(val==0)$input.val( val+1 ).change();
	   //~ });
	   //~ $(".themsoluong.loai3 .qtyminus.minus").click(function(event){
		 //~ let $input = $(this).next('input.qty');
		//~ var val = parseInt($input.val());
		//~ var x=0;
		//~ if($input.parent().parent().attr('id')=="khach"){x=1;};
		//~ if (val > x) {
			//~ $input.val( val-1 ).change();
		//~ } 
	   //~ });
	   //~ $(".themsoluong.loai4 .qtyplus.plus").click(function(event){
		 //~ let $input = $(this).prev('input.qty');
		//~ let val = parseInt($input.val());
		//~ var id = $(this).parent().parent().attr('id');
		//~ if(val==0){$input.val( 20+"k" ).change();}
		//~ if(val>0 && val<50){$input.val( val+10+"k" ).change();}
	   //~ });
	   //~ $(".themsoluong.loai4 .qtyminus.minus").click(function(event){
		 //~ let $input = $(this).next('input.qty');
		//~ let val = parseInt($input.val());
		//~ var x=0;
		//~ if (val > x) {
			//~ if(val>20)$input.val( val-10+"k" ).change();
			//~ if(val==20)$input.val("0").change();
		//~ } 
	   //~ });
	 //~ var khachgoi = [];
	var stt;
	var sttkhach;
	var don;

//~ function chotkhach(sttkhach){
	//~ mon1= $('#menu .mon1 .checklist input[type="checkbox"]:checked').map(function() {
            //~ return $(this).val();
        //~ }).get().join('');
    //~ console.log(mon1);
    //~ if(mon1!="")mon1=mon1+"";
    //~ size1 = $('#menu .size1 .checklist input[type="checkbox"]:checked').map(function() {
            //~ return $(this).val();
        //~ }).get().join('');
	//~ mon2 = $('#menu .mon2 .checklist input[type="checkbox"]:checked').map(function() {
            //~ return $(this).val();
        //~ }).get().join(' ');
		//~ if(mon2!="")mon2=" "+mon2;
	//~ tuychon = $('#menu .tuychon .checklist input[type="checkbox"]:checked').map(function() {
            //~ return $(this).val();
        //~ }).get().join(' ');
        //~ if(tuychon!="")tuychon=" "+tuychon;
		//~ them= $('#menu #them .checklist input.qty').map(function() {
            //~ if(parseInt($(this).val()) > 0){
            //~ var ten=$(this).parent().parent().find("label").attr('name').substring(4);
            //~ console.log("x"+$(this).val()+""+ten);
            //~ return $(this).val()+""+ten;
		//~ }
        //~ }).get().join(' ');
        //~ if(them.length>0){them=" "+them};
		//~ 
		 //~ mon=mon1+size1+mon2+tuychon+them;
		 //~ if(mon!=""){khachgoi[sttkhach]=sttkhach+": "+mon;}
		 //~ console.log(khachgoi[sttkhach]);
	//~ mon1="";size1="";mon2="";tuychon="";them="";mon="";	 
	//~ 
//~ }
//~ $("#khach .themsoluong input[type='button'].qtyplus.plus").click(function(event){
	//~ sttkhach=parseInt($("#khach input.qty").val())-1;
	//~ chotkhach(sttkhach);
	//~ $('#menu input[type="checkbox"]').prop('checked', false);
	//~ $('#menu input[type="number"]').val('0');
	//~ loadkhach(sttkhach+1);
	 //~ });
//~ function loadkhach(sttkhach){
	//~ 
	//~ var str;
	//~ if(khachgoi.length>sttkhach){
	//~ str=khachgoi[sttkhach].substring(2).split(" ");
//~ for (let i = 0; i < str.length; i++) { 
	//~ console.log(str[i]);
	//~ if(i==1){
		//~ var m=str[i].split("bat");
		//~ for (let k = 0; k < m.length; k++) { 
			//~ var id;
			//~ if(k==0)id="#"+m[k];
			//~ if(k==1)id="#bat"+m[k];
			//~ id=id.replace(" ","");
			//~ 
			//~ $(id).prop('checked', true);
			//~ continue;
		//~ }
	//~ }
	//~ var id="#"+str[i];
	//~ if(document.getElementById(str[i])){
	//~ $(id).prop('checked', true);
	//~ }
	//~ 
	 //~ if(!isNaN(parseInt(str[i]))){
		 //~ id=str[i].replace(/[0-9]/g, '');
		 //~ var n=parseInt(str[i]);
		//~ if(id.substring(0,1)=='k'){id=id.substring(1);n=n+'k';}
		//~ id=id.replace(/ /g,"");
		//~ id="#them"+id;
		//~ var t=id+" input.qty";	
		//~ console.log(t);	
		//~ $(t).val(n);
		//~ 
	//~ }
//~ }
//~ }
//~ }
//~ $("#khach .themsoluong input[type='button'].qtyminus.minus").click(function(event){
	//~ sttkhach=parseInt($("#khach input.qty").val());
	//~ chotkhach(sttkhach+1);
	//~ $('#menu input[type="checkbox"]').prop('checked', false);
	//~ $('#menu input[type="number"]').val('0');
	//~ loadkhach(sttkhach);
	//~ 
//~ 
//~ 
//~ 
  //~ 
//~ 
	//~ 
//~ 
//~ 
	 //~ });
	//~ 
	//~ var donhang;
 //~ $("#chotdon .submit").click(function(event){
	 //~ 
		//~ sttkhach=$("#khach input.qty").val();
		//~ 
		 //~ chotkhach(sttkhach);
		 //~ 
		 //~ themsua();
	 //~ donhang=khachgoi.join('\n').substring(1);
	 //~ donhang=$.trim(donhang);
	 //~ //donhang=tiengviet(donhang);
	 //~ inbep=lamthem.join('\n').substring(1);
	 //~ inbep=tiengviet(inbep);
	 //~ $('#don').html(inbep);
		//~ $('#datmon').toggle();
		//~ $('#dienstt').toggle();
		//~ $('#back').toggle();
		//~ 
	   //~ });
//~ function delgapNT(str){
	//~ var x=str.split(' ');
	//~ var r="";
	//~ for (let i = 0; i < x.length; i++) { 
		//~ if(!isNaN(x[i])){
			//~ x[i]=x[i]+x[i+1];
			//~ r=r+" "+x[i];
			//~ r=$.trim(r);
			//~ i++;
			//~ continue;
		//~ }
		//~ r=r+" "+x[i];
			//~ r=$.trim(r);
		//~ 
	//~ }
	//~ return r;
//~ }
//~ function reverse(str){
    //~ return [...str].reverse().join("");
//~ }
//~ function thoigian(){
	//~ var d = new Date();
    //~ var utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    //~ var nd = new Date(utc + (3600000*7));
//~ return nd.toLocaleString("vi-VN")
//~ }
//~ function tiengviet(str){
	//~ str=str.replace(/gautrang/g,"gấutrắng");
//~ str=str.replace(/nuocbeo/g,"nướcbéo");
//~ str=str.replace(/muoitai/g,"muôitái");
//~ str=str.replace(/muoinam/g,"muôinạm");
//~ str=str.replace(/muoigau/g,"muôigàu");
//~ str=str.replace(/muoicuongtim/g,"muôicuốngtim");
//~ str=str.replace(/muoitimcat/g,"muôitimcật");
//~ str=str.replace(/muoibap/g,"muôibắp");
//~ str=str.replace(/muoisotvang/g,"muôisốtvang");
//~ str=str.replace(/muoimoc/g,"muôimộc");
//~ str=str.replace(/muoigan/g,"muôigan");
//~ str=str.replace(/pho/g,"phở");
//~ str=str.replace(/bun/g,"bún");
//~ str=str.replace(/mitom/g,"mìtôm");
//~ str=str.replace(/nhung/g,"nhúng");
//~ str=str.replace(/batbe/g,"bátbé");
//~ str=str.replace(/bat30/g,"bát30");
//~ str=str.replace(/bat35/g,"bát35");
//~ str=str.replace(/bat40/g,"bát40");
//~ str=str.replace(/bat50/g,"bát50");
//~ str=str.replace(/bat80/g,"bát80");
//~ str=str.replace(/bat100/g,"bát100");
//~ str=str.replace(/bat120/g,"bát120");
//~ str=str.replace(/bat150/g,"bát150");
//~ str=str.replace(/thapcam/g,"thậpcẩm");
//~ str=str.replace(/tai/g,"tái");
//~ str=str.replace(/nam/g,"nạm");
//~ str=str.replace(/gau/g,"gầu");
//~ str=str.replace(/cuongtim/g,"cuốngtim");
//~ str=str.replace(/timcat/g,"timcật");
//~ str=str.replace(/bap/g,"bắp");
//~ str=str.replace(/sotvang/g,"sốtvang");
//~ str=str.replace(/moc/g,"mộc");
//~ str=str.replace(/gan/g,"gan");
//~ str=str.replace(/beo/g,"béo");
//~ str=str.replace(/gia/g,"giá");
//~ str=str.replace(/itbanh/g,"ítbánh");
//~ str=str.replace(/nhieubanh/g,"nhiềubánh");
//~ str=str.replace(/ithanh/g,"íthành");
//~ str=str.replace(/nhieuhanh/g,"nhiềuhành");
//~ str=str.replace(/khonghanh/g,"khônghành");
//~ str=str.replace(/khongmichinh/g,"khôngmìchính");
//~ str=str.replace(/dauphu/g,"đậuphụ");
//~ str=str.replace(/trung/g,"trứng");
//~ str=str.replace(/longtrang/g,"lòngtrắng");
//~ str=str.replace(/quay/g,"quẩy");
//~ str=str.replace(/ruou/g,"rượu");
//~ str=str.replace(/ruoungon/g,"rượungon");
//~ str=str.replace(/gia/g,"giá");
//~ str=str.replace(/bohuc/g,"bòhúc");
//~ str=str.replace(/coca/g,"côca");
//~ str=str.replace(/nuocloc/g,"nướclọc");
//~ 
//~ 
//~ return str;
//~ }
//~ var lamthem=[];
//~ function themsua(){
	//~ 
	//~ 
  //~ for (let i = 0; i < Math.min(khachgoi.length,khachgoicu.length); i++) { 
	//~ var sau=delgapNT(khachgoi[i]);
	//~ var truoc=delgapNT(khachgoicu[i]);
	//~ console.log(sau+" | "+truoc);
	//~ if(sau!=truoc){
		//~ 
		//~ let output = htmldiff(sau, truoc);
		//~ console.log(output);
		//~ while(output.indexOf('</del><ins>')!=-1){
				//~ var m=output.indexOf('</del><ins>');
				//~ var thay=output.substring(0,m);
				//~ thay=reverse(thay);
				//~ thay=thay.substring(0,thay.indexOf('>led<'));
				//~ thay=reverse(thay);
				//~ //console.log(thay);
				//~ var bo=output.substring(m+11);
				//~ bo=bo.substring(0,bo.indexOf('</ins>'));
				//~ //console.log(bo);
				//~ var e=output.indexOf(bo+'</ins>');
				//~ e=e+bo.length+6;
				//~ output=$.trim(output.replace('<del>'+thay+'</del><ins>'+bo+'</ins>',""));
				//~ //var e=output.indexOf('</ins>');
				//~ //var s=output.indexOf('<del>')+5;
				//~ 
				//~ //var d=output.substring(s,e);
				//~ //output=$.trim(output.substring(e+6));
				//~ //var bo=d.substring(d.indexOf('<ins>')+5);
				//~ //var thay=d.substring(0,d.indexOf('</del><ins>'));
				//~ //console.log("1 "+thay);
				//~ //thay=reverse(thay).substring(0,thay.indexOf('>led<'));
				//~ //console.log("2 "+thay);
				//~ //thay=reverse(thay);
				//~ //console.log("3 "+thay);
				//~ var o;
				//~ if(typeof lamthem[i] == 'undefined'){o="";}else{o=lamthem[i];};
				//~ if(thay.indexOf('bat')!=-1){
					//~ var s=thay.substring(0,thay.indexOf('bat'));
					//~ if(s==$.trim(bo))bo=bo+"thường";
					//~ console.log(s);
				//~ }
				//~ 
				//~ console.log(" bỏ "+bo+" gọi "+thay);
				//~ lamthem[i]=o+" bỏ "+bo+" gọi "+thay;
				//~ 
			//~ }
		//~ var thembool;
		//~ //if(output.indexOf('</del><ins>')==-1){
			//~ while(output.indexOf('<del>')!=-1){
				//~ 
				//~ var s=output.indexOf('<del>')+5;
				//~ var e=output.indexOf('</del>');
				//~ var d=output.substring(s,e);
				//~ d=$.trim(d);
				//~ output=$.trim(output.substring(e+6));
				//~ output=$.trim(output.replace('<del>'+d+'</del>',""));
				//~ console.log(d);
				//~ console.log(output);
				//~ //neu thay doi so luong
				//~ if(!isNaN(parseInt(d))){
					//~ //console.log(output);
					//~ //var o;
					//~ if(typeof lamthem[i] == 'undefined'){o="";}else{o=lamthem[i];};
					//~ //var ee=output.indexOf(' ');
					//~ //var tt=output.indexOf('<');
					//~ //var dd=output.substring(0,ee);
					//~ //output=$.trim(output.substring(ee+1));
					//~ //console.log(dd);
					//~ if(o==""){lamthem[i]=" "+d;}else{lamthem[i]=o+" thêm "+d;};
					//~ thembool="true";
				//~ }else{
					//~ var o;
					//~ if(typeof lamthem[i] == 'undefined'){o="";}else{o=lamthem[i];};
					//~ lamthem[i]=o+" thêm "+d;
					//~ thembool="true";
				//~ }
				//~ 
				//~ 
				//~ 
			//~ }
			//~ var bobool;
			//~ 
			//~ while(output.indexOf('<ins>')!=-1){
				//~ 
				//~ var s=output.indexOf('<ins>')+5;
				//~ var e=output.indexOf('</ins>');
				//~ var d=output.substring(s,e);
				//~ output=$.trim(output.substring(e+6));
				//~ output=$.trim(output.replace('<ins>'+d+'</ins>',""));
				//~ //neu thay doi so luong
				//~ if(!isNaN(parseInt(d))){
					//~ var o;
					//~ if(typeof lamthem[i] == 'undefined'){o="";}else{o=lamthem[i];};
					//~ var ee=output.indexOf(' ');
					//~ var tt=output.indexOf('<');
					//~ var dd=output.substring(0,ee);
					//~ output=$.trim(output.substring(ee+1));
					//~ if(o==""){lamthem[i]=" "+d;}else{lamthem[i]=o+" "+dd;};
					//~ bobool="true";
				//~ }else{
					//~ var o;
					//~ if(typeof lamthem[i] == 'undefined'){o="";}else{o=lamthem[i];};
					//~ lamthem[i]=o+" "+d;
					//~ bobool="true";
				//~ }
				//~ 
				//~ 
				//~ 
			//~ }
			//~ 
			//~ if(thembool=="true"){lamthem[i]=i+" thêm: "+$.trim(lamthem[i]);}
			//~ if(bobool=="true"){lamthem[i]=i+" bỏ: "+$.trim(lamthem[i]);}
			//~ lamthem[i]=lamthem[i]+"\n"+"->"+khachgoi[i];
				//~ console.log(lamthem[i]);
		//~ //}else{
			//~ 
			//~ //lamthem[i]=i+": "+$.trim(lamthem[i]);
			//~ //console.log(lamthem[i]);
		//~ //}
		//~ 
	//~ }
  //~ }
  //~ 
  //~ //them khach
  //~ if(khachgoicu.length<khachgoi.length){
	  //~ var n=khachgoi.length-khachgoicu.length;
	  //~ for (let i = 0; i < n; i++) { 
	  //~ var khachmoi=khachgoi[khachgoi.length-1+i]
	  //~ if(typeof khachmoi != 'undefined'){
	  //~ khachmoi=" khách mới "+khachmoi;
	  //~ //console.log(khachmoi)
	  //~ lamthem.push(khachmoi);
  //~ }
	//~ }
  //~ }
//~ }
//~ var inbep;
//~ $('#dienstt input[type="button"].submit').click(function(event){
	//~ 
	//~ 
	//~ 
  //~ 
  //~ var str="Thẻ số: "+stt+"\n"+"Bàn số: "+$($('#dienstt input[type="number"]')[1]).val()+" *\n";  
  //~ 
  //~ lamthem = lamthem.filter(function( element ) {
   //~ return element !== undefined;
//~ });
  //~ 
 //~ inbep=str+inbep;
 //~ console.log(inbep);
   //~ 
   //~ donhang=str+donhang;
//~ $.ajax({
  //~ method: "POST",
  //~ url: "/datmon/ajax.php",
  //~ data: { donhang: donhang, stt: $($('#dienstt input[type="number"]')[0]).val() }
//~ 
//~ })
//~ 
//~ $.ajax({
  //~ method: "POST",
  //~ url: "/in.php",
  //~ data: { inbep: inbep, stt: $($('#dienstt input[type="number"]')[0]).val(), trangthai: "goithem" }
//~ 
//~ })
	//~ 
//~ });
//~ $('#dienstt input[type="button"].back').click(function(event){
	//~ lamthem="";
	//~ lamthem=[];
	//~ $('#datmon').toggle();
		//~ $('#dienstt').toggle();
		//~ $('#back').toggle();
//~ });
//~ 
$('#dienstt input[type="button"].submit').click(function(event){
	var t=$($('#dienstt input[type="number"]')[1]).val();
	if(t!=""){banso=t;};
	var str="Thẻ số: "+$($('#dienstt input[type="number"]')[0]).val()+"\n"+"Bàn số: "+banso+" * \n";
    donhang=tiengviet(donhang,"bodau");
    donhang=str+donhang;
    var inbep=str+tiengviet(themsua,"themdau");
    
   console.log("donhang:"+donhang);
$.ajax({
  method: "POST",
  url: "/datmon/ajax.php",
  data: { donhang: donhang, stt: $($('#dienstt input[type="number"]')[0]).val() }

})
console.log("inbep:"+inbep);
$.ajax({
  method: "POST",
  url: "/in.php",
  data: { inbep: inbep, stt:  $($('#dienstt input[type="number"]')[0]).val(), trangthai: "goithem" }

})

    
	//~ $('#datmon').toggle();
		//~ $('#dienstt').toggle();
	
});

	 });
	
	
    </script>

  </head>
  <body>
<span id='tracuu'>
	<h1>Thẻ số:</h1>
	<input type='number' name='stt' value='' class='stt' />
    <input type='button' value='OK' class='submit stt'/>
    
</span>
<span id='suamon'>
<span id='datmon' class="startuphidden">
<!--
	<div id="khach" class="checklist">
	  <label for="khach"> Thẻ số:</label>
	  <div class="themsoluong loai1">
		  <input type='button' value='<' class='qtyminus minus' field='quantity' />
		  <input type='number' name='quantity' value='1' class='qty' min="1" readonly/>
		  <input type='button' value='>' class='qtyplus plus' field='quantity' />
	  </div>
	  
  </div>
-->
	
	<form id="menu" class="suadonhang taodon" action="/action_page.php">
		<div class="soluong">
			<div class=" grant">
				<div class="parent">
					<button type='button' class="children" field="quantity" name="moibat" >mỗi bát</button>
					<button type='button' class="children" field="quantity" name="1" >1</button>
					<button type='button' class="children" field="quantity" name="2" >2</button>
					<button type='button' class="children" field="quantity" name="3" >3</button>
					<button type='button' class="children" field="quantity" name="4" >4</button>
					<button type='button' class="children" field="quantity" name="5" >5</button>
					<button type='button' class="children" field="quantity" name="6" >6</button>
					<button type='button' class="children" field="quantity" name="7" >7</button>
					<button type='button' class="children" field="quantity" name="8" >8</button>
					<button type='button' class="children" field="quantity" name="9" >9</button>
					<button type='button' class="children" field="quantity" name="10" >10</button>
					<button type='button' class="children" field="quantity" name="11" >11</button>
					<button type='button' class="children" field="quantity" name="12" >12</button>
					<button type='button' class="children" field="quantity" name="13" >13</button>
					<button type='button' class="children" field="quantity" name="14" >14</button>
					<button type='button' class="children" field="quantity" name="15" >15</button>
					<button type='button' class="children" field="quantity" name="16" >16</button>
					<button type='button' class="children" field="quantity" name="17" >17</button>
					<button type='button' class="children" field="quantity" name="18" >18</button>
					<button type='button' class="children" field="quantity" name="19" >19</button>
					<button type='button' class="children" field="quantity" name="20" >20</button>
					
				</div>
			</div>
		</div>
		<div class="mon1 soluongshow">
			<div class="checklist loai1 noactive">
			  <button type='button' class="children" field="quantity" name="pho" >Phở</button>
			  <button type='button' class="children" field="quantity" name="bun" >Bún</button>
			  <button type='button' class="children" field="quantity" name="mitom" >Mì</button>
			  <button type='button' class="children" field="quantity" name="nhung" >Nhúng</button>
			</div>
		</div>
		
		
		
		<div class="mon2 startuphidden">
			  <div class="checklist">
				  <button type='button' class="children" field="quantity" name="thapcam" >thậpcẩm</button>
				  <button type='button' class="children" field="quantity" name="tai" >tái</button>
				  <button type='button' class="children" field="quantity" name="namchin" >nạmchín</button>
				  <button type='button' class="children" field="quantity" name="gau" >gầu</button>
				  <button type='button' class="children" field="quantity" name="cuongtim" >cuốngtim</button>
				  <button type='button' class="children" field="quantity" name="timcat" >timcật</button>
				 <button type='button' class="children" field="quantity" name="bap" >bắp</button>
				 <button type='button' class="children" field="quantity" name="sotvang" >sốtvang</button>
				 <button type='button' class="children" field="quantity" name="moc" >mộc</button>
				  <button type='button' class="children" field="quantity" name="gan" >gan</button>
				  
				  
			  </div>
			  
			  
			  
	</div>
	<div class="size1 startuphidden">
			<div class="checklist loai1">
				<button type='button' class="children" field="quantity" name="batbe" >bé</button>
				<button type='button' class="children" field="quantity" name="bat35" >35k</button>
				<button type='button' class="children" field="quantity" name="bat40" >40k</button>
				<button type='button' class="children" field="quantity" name="bat50" >50k</button>
			</div>
			<div class="checklist loai2">
				<button type='button' class="children" field="quantity" name="bat80" >80k</button>
				<button type='button' class="children" field="quantity" name="bat100" >100k</button>
				<button type='button' class="children" field="quantity" name="bat120" >120k</button>
				<button type='button' class="children" field="quantity" name="bat150" >150k</button>
				
				
			</div>
		</div>
	
	<div class="tuychon startuphidden">
		<div class="checklist">
				<button type='button' class="children" field="quantity" name="conuocbeo" >cóbéo</button>
				<button type='button' class="children" field="quantity" name="cogia" >cógiá</button>
				<button type='button' class="children" field="quantity" name="itbanh" >ítbánh</button>
				<button type='button' class="children" field="quantity" name="nhieubanh" >nhiềubánh</button>
				<button type='button' class="children" field="quantity" name="ithanh" >íthành</button>
				<button type='button' class="children" field="quantity" name="nhieuhanh" >nhiềuhành</button>
				<button type='button' class="children" field="quantity" name="khonghanh" >khônghành</button>
				<button type='button' class="children" field="quantity" name="khongmichinh" >kh.mìchính</button>
				
	</div>
	</div>
	  
	<div id="them" class="soluongshow">		
		<div class="checklist">
				<button type='button' class="children" field="quantity" name="dauphu" >đậuphụ</button>
				
				<button type='button' class="children" field="quantity" name="longtrang" >lòngtrắng</button>
				<button type='button' class="children" field="quantity" name="quay" >quẩy</button>
				<button type='button' class="children" field="quantity" name="ruou" >rượu</button>
				<div class="giatien .checklist">
					<button type='button' class="children" field="quantity" name="5k" >5k</button>
					<button type='button' class="children" field="quantity" name="10k" >10k</button>
					<button type='button' class="children" field="quantity" name="15k" >15k</button>
					<button type='button' class="children" field="quantity" name="20k" >20k</button>
				</div>
				<button type='button' class="children" field="quantity" name="trung" >trứng</button>
				
				<button type='button' class="children" field="quantity" name="ruoungon" >rượungon</button>
				<button type='button' class="children" field="quantity" name="bohuc" >bòhúc</button>
				<button type='button' class="children" field="quantity" name="gautrang" >gấutrắng</button>
				<button type='button' class="children" field="quantity" name="coca" >coca</button>
				<button type='button' class="children" field="quantity" name="nuocloc" >nướclọc</button>
				<button type='button' class="children" field="quantity" name="muoitai" >muôitái</button>
				<button type='button' class="children" field="quantity" name="muoinam" >muôinạm</button>
				<button type='button' class="children" field="quantity" name="muoigau" >muôigầu</button>
				<button type='button' class="children" field="quantity" name="muoicuongtim" >muôicuốngtim</button>
				<button type='button' class="children" field="quantity" name="muoitimcat" >muôitimcật</button>
				<button type='button' class="children" field="quantity" name="muoibap" >muôibắp</button>
				<button type='button' class="children" field="quantity" name="muoisotvan" >muôisốtvang</button>
				<button type='button' class="children" field="quantity" name="muoimoc" >muôimọc</button>
				<button type='button' class="children" field="quantity" name="muoigan" >muôigan</button>
				
			</div>
			
		</div>
	</div>
	</form>
	<div id="chotdon" >
		<input class="submit" type="submit" value="OK">
		
	</div>
	
	
</span>
<span id="duyetdonhang" class="">
	<input id="duyetdon" type="button" value="OK" class="submit duyetdon"/>
	<form id="donhang" action="/action_page.php">
		
	</form>
	
	<input id="suadonhangnay" type="button" value="OK" class="submit suadonhang startuphidden"/>

</span>
<span id='dienstt'>
	<pre id='don'></pre>

	<h1>Thẻ số:</h1>
	<input type='number' name='dienstt' value='' class='dienstt'/>

	<h1>Bàn số:</h1>
	<input type='number' name='banso' value='' class='banso' />


<a href='/suamon'>
		<input type='button' value='OK' class='submit dienstt'/>
	</a>
	<input type='button' value='Quay lại' class='back'/>
</span>

</span>
<span id='ketqua'>
<pre></pre>
<input type='button' value='Quay lại' class='back'/>
</span>
<span id='back'>
<a href='../' target='_self'><input type='button' value='Quay lại' class='back'/></a>
<a href="/datmon/index.php" target="_self"><input type='button' value='Đặt món' class='datmonmoi'</button></a>
<a href="/thanhtoan/index.php" target="_self"><input type='button' value='Thanh toán' class=thanhtoan'</button></a>
</span>
</body></html>
