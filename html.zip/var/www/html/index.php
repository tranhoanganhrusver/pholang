

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0017)http://localhost/ -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title></title>
    <meta meta name="viewport" content="user-scalable=no" />
    <style></style>
  </head>
  <body>
	<table style="
    width: 100%;
    margin-top: 20%;
">
		<tbody><tr><td><a href="./datmon" target="_self"><button style="
    width: 100%;
    font-size: 80px;
    height: 4em;
    margin: 10%;
">Đặt món</button></a></td></tr>
<tr><td><a href="./suamon" target="_self"><button class="boss" style="
    width: 100%;
    font-size: 80px;
    height: 4em;
    margin: 10%;
">Sửa/thêm món</button></a></td></tr>
		<tr><td><a href="./thanhtoan" target="_self"><button class="boss" style="
    width: 100%;
    font-size: 80px;
    height: 4em;
    margin: 10%;
">Thanh toán</button></a></td></tr>

	</tbody></table>
  


</body></html>
